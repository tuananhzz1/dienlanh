<?php
// Cấu hình kết nối đến cơ sở dữ liệu MySQL
$servername = "localhost";
$username = "dienlan9_3";
$password = "983011@0abc";
$dbname = "dienlan9_code3";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Thiết lập charset để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");
?>
