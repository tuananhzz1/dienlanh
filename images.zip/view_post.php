<?php
include 'config.php';

// Lấy bài viết dựa trên slug
if (isset($_GET['slug'])) {
    $slug = $_GET['slug'];
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE slug = ?");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $post = $result->fetch_assoc();
    } else {
        echo "<h1>Bài viết không tồn tại.</h1>";
        exit;
    }
} else {
    echo "<h1>Không tìm thấy bài viết.</h1>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?> - Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body class="container py-4">
    <header class="mb-4">
        <h1 class="text-center">Điện Lạnh Anh Trần Đà Nẵng</h1>
        <nav class="nav justify-content-center mb-3">
            <a class="nav-link" href="index.php">Trang chủ</a>
            <a class="nav-link" href="blog.php">Bài viết</a>
        </nav>
    </header>
    <main>
        <div class="card mb-4">
            <div class="card-body">
                <h2 class="card-title"><?php echo htmlspecialchars($post['title']); ?></h2>
                <p class="text-muted">Ngày đăng: <?php echo date('d/m/Y - H:i:s', strtotime($post['created_at'])); ?></p>
                <?php if ($post['image']) { ?>
                    <img src="<?php echo htmlspecialchars($post['image']); ?>" class="img-fluid mb-4" alt="<?php echo htmlspecialchars($post['title']); ?>">
                <?php } ?>
                <div class="content">
                    <?php echo nl2br($post['content']); ?>
                </div>
            </div>
        </div>
    </main>
    <footer class="text-center mt-4">
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>
</body>
</html>
