<?php
include 'config.php';

// Thiết lập charset để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");

// Lấy danh sách bài viết từ cơ sở dữ liệu
$sql = "SELECT * FROM blog_posts ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài Viết - Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f1f1f1;
            margin: 0;
        }
        header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        nav a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
        }
        .blog-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(540px, 1fr));
            gap: 20px;
            padding: 20px;
            justify-content: center;
        }
        .blog-post {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
            display: flex;
            gap: 15px;
            max-width: 540px;
            height: 138.14px;
            align-items: center;
            justify-content: center;
        }
        .blog-post:hover {
            transform: scale(1.02);
        }
        .blog-post img {
            width: 170px;
            height: 150px;
            object-fit: cover;
            border-radius: 4px;
        }
        .blog-post-content {
            flex: 1;
        }
        .blog-post h2 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        .blog-post p {
            margin-bottom: 10px;
            color: #555;
        }
        footer {
            text-align: center;
            padding: 20px;
            background: #007bff;
            color: #fff;
            margin-top: 20px;
        }
        @media (max-width: 768px) {
            .blog-list {
                grid-template-columns: repeat(auto-fit, minmax(382px, 1fr));
            }
            .blog-post {
                flex-direction: column;
                align-items: center;
                text-align: center;
                max-width: 382px;
                height: auto;
            }
            .blog-post img {
                width: 170px;
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Bài Viết Mới Nhất</h1>
        <nav>
            <a href="index.php">Trang chủ</a>
            <a href="vietbai.php">Viết bài mới</a>
        </nav>
    </header>
    <main>
        <section class="blog-list">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="blog-post">
                        <img src="<?php echo !empty($row['image']) ? htmlspecialchars($row['image'], ENT_QUOTES, 'UTF-8') : 'default-image.jpg'; ?>" alt="<?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="blog-post-content">
                            <h2><a href="view_post.php?slug=<?php echo $row['slug']; ?>"><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></a></h2>
                            <p><?php echo (!empty($row['description']) && trim($row['description']) !== '') ? htmlspecialchars(substr($row['description'], 0, 100) . '...', ENT_QUOTES, 'UTF-8') : 'Không có mô tả'; ?></p>
                            <p><em>Ngày đăng: <?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?></em></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Chưa có bài viết nào.</p>
            <?php endif; ?>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>
</body>
</html>
