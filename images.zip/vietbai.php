<?php
include 'config.php';

// Thiết lập charset để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");

// Xử lý khi người dùng gửi bài viết
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $slug = strtolower(preg_replace('/[^a-zA-Z0-9\p{L}]+/u', '-', trim($title)));
    $description = $_POST['description'];
    $content = $_POST['content'];
    $date = date('Y-m-d H:i:s');
    $image = '';

    // Kiểm tra và tải lên hình ảnh nếu có
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image = $targetFile;
        } else {
            echo "Có lỗi xảy ra khi tải lên hình ảnh.";
        }
    }

    // Chuẩn bị câu truy vấn để thêm bài viết vào cơ sở dữ liệu
    if ($stmt = $conn->prepare("INSERT INTO blog_posts (title, slug, description, content, image, created_at) VALUES (?, ?, ?, ?, ?, ?)")) {
        $stmt->bind_param("ssssss", $title, $slug, $description, $content, $image, $date);

        if ($stmt->execute()) {
            echo "Bài viết đã được đăng thành công!";
        } else {
            echo "Có lỗi xảy ra khi đăng bài viết: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Có lỗi xảy ra khi chuẩn bị câu truy vấn: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viết Bài Mới - Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.ckeditor.com/4.20.2/standard/ckeditor.js"></script>
</head>
<body>
    <header>
        <h1>Viết Bài Mới</h1>
        <nav>
            <a href="index.php">Trang chủ</a>
            <a href="blog.php">Bài viết</a>
        </nav>
    </header>
    <main>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Tiêu Đề Bài Viết:</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="description">Mô Tả:</label>
                <textarea id="description" name="description" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="image">Chọn Hình Ảnh:</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>
            <div class="form-group">
                <label for="content">Nội Dung:</label>
                <textarea id="content" name="content" required></textarea>
            </div>
            <button type="submit">Đăng Bài Viết</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            if (typeof CKEDITOR !== 'undefined') {
                CKEDITOR.replace('content');
            } else {
                console.error('CKEDITOR is not defined');
            }
        });
    </script>
</body>
</html>
