<?php
include 'config.php';

// Thiết lập charset để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");

// Lấy slug từ URL
$service_slug = isset($_GET['slug']) ? $_GET['slug'] : '';

// Lấy chi tiết dịch vụ từ cơ sở dữ liệu theo slug
$sql = "SELECT title, additional_content FROM services WHERE service_slug = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $service_slug);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $service = $result->fetch_assoc();
} else {
    echo "Dịch vụ không tồn tại.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($service['title'], ENT_QUOTES, 'UTF-8'); ?> - Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        /* Đảm bảo nội dung hiển thị tốt trên cả điện thoại và máy tính */
        #additional_content {
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        h2, h3, h4 {
            width: 100%;
            font-size: 1.6em;
            word-break: break-word;
        }
        img {
            max-width: 100%;
            height: auto;
        }
        table {
            width: 100%;
            table-layout: auto;
            overflow-x: auto;
            display: block;
            word-wrap: break-word;
            border-collapse: collapse;
        }
        th, td {
            word-wrap: break-word;
            text-align: left;
            padding: 8px;
            border: 1px solid #ddd;
        }
        /* Điều chỉnh font chữ và kích thước phù hợp trên các thiết bị khác nhau */
        body {
            font-size: 1rem;
        }
        span {
            font-size: 1em;
            word-break: break-word;
            display: block;
            white-space: normal;
        }
        h2 span {
            width: 100%;
            display: block;
            white-space: normal;
        }
        @media (max-width: 768px) {
            h2 {
                font-size: 1.4rem;
                word-break: break-word;
            }
            #additional_content {
                font-size: 0.9rem;
            }
            span {
                font-size: 0.9em;
            }
            table {
                font-size: 0.8rem;
                overflow-x: auto;
                display: block;
            }
            th, td {
                font-size: 0.8rem;
                word-wrap: break-word;
                padding: 6px;
            }
            h2, h3, h4 {
                font-size: 1.2rem;
                word-break: break-word;
            }
        }

        /* Thêm CSS để đảm bảo bảng và nội dung co giãn tốt trên thiết bị nhỏ */
        .service-additional-content {
            overflow-x: hidden;
        }
        table {
            width: 100%;
            table-layout: auto;
        }

        /* Sửa lỗi không tự xuống dòng tiêu đề và văn bản */
        .service-additional-content h2, .service-additional-content span, .service-additional-content p {
            white-space: normal;
            word-break: break-word;
            overflow-wrap: break-word;
        }
        /* Thêm thuộc tính để đảm bảo tiêu đề span tự động xuống dòng */
        .service-additional-content span {
            display: block;
            white-space: normal;
            overflow-wrap: break-word;
        }
    </style>
</head>
<body class="container py-4">
    <header class="mb-4">
        <h1 class="text-center">Điện Lạnh Anh Trần Đà Nẵng</h1>
        <nav class="nav justify-content-center mb-3">
            <a class="nav-link" href="index.php">Trang chủ</a>
            <a class="nav-link" href="blog.php">Bài viết</a>
            <a class="nav-link" href="services.php">Dịch vụ</a>
        </nav>
    </header>

    <main>
        <section class="service-detail">
            <h2 class="text-center mb-4" style="word-break: break-word; white-space: normal; overflow-wrap: break-word;"> <?php echo htmlspecialchars($service['title'], ENT_QUOTES, 'UTF-8'); ?> </h2>
            <div id="additional_content" class="service-additional-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <?php echo $service['additional_content']; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="text-center mt-4">
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
