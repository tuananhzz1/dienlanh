<?php
include 'config.php';

// Thiết lập charset để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");

// Lấy danh sách dịch vụ từ cơ sở dữ liệu
$sql = "SELECT * FROM services ORDER BY id DESC";
$result = $conn->query($sql);

// Lấy danh sách bài viết từ cơ sở dữ liệu
$sql_articles = "SELECT * FROM articles ORDER BY id DESC LIMIT 6";
$result_articles = $conn->query($sql_articles);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f9f9f9;
        }
        .card {
            border-radius: 15px;
            overflow: hidden;
            transition: transform 0.2s;
            text-align: center;
            background: rgba(255, 255, 255, 0.9);
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card-img-top {
            width: 97px;
            height: 97px;
            border-radius: 50%;
            margin-top: 15px;
        }
        .card-title {
            background-color: #007bff;
            color: white;
            padding: 10px;
            margin-top: 15px;
        }
        .card-title a {
            color: white;
            text-decoration: none;
        }
        .card-title a:hover {
            text-decoration: underline;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            width: fit-content;
            padding: 5px 15px;
            font-size: 14px;
            margin: 10px auto;
            display: block;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .service-issues {
            text-align: left;
            margin-top: 10px;
            padding-left: 20px;
        }
        .service-issues li {
            list-style: none;
            padding-left: 1.5em;
            position: relative;
            margin-bottom: 5px;
        }
        .service-issues li:before {
            content: '\2022';
            color: #007bff;
            font-weight: bold;
            display: inline-block;
            width: 1em;
            position: absolute;
            left: 0;
        }
        .card-body {
            height: auto; /* Đảm bảo chiều cao tự động phù hợp với nội dung */
            overflow: visible; /* Tránh cắt nội dung */
        }
        header {
            background: linear-gradient(to right, #007bff, #00d4ff);
            padding: 20px;
            color: white;
        }
        header h1 {
            font-size: 2rem;
        }
        nav a {
            color: white;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        nav a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        .hamburger-menu {
            display: none;
            font-size: 2rem;
            cursor: pointer;
        }
        .nav-links {
            display: flex;
        }
        @media (max-width: 768px) {
            header h1 {
                font-size: 1.5rem;
            }
            .card-title {
                font-size: 1rem;
            }
            .btn-primary {
                font-size: 12px;
                padding: 3px 10px;
            }
            .hamburger-menu {
                display: block;
            }
            .nav-links {
                display: none;
                flex-direction: column;
                background: #007bff;
                position: absolute;
                top: 60px;
                right: 20px;
                padding: 10px;
                border-radius: 5px;
            }
            .nav-links a {
                color: white;
                padding: 10px;
                text-align: left;
            }
            .nav-links.show {
                display: flex;
            }
        }
    </style>
    <script>
        function toggleMenu() {
            const navLinks = document.querySelector('.nav-links');
            navLinks.classList.toggle('show');
        }
    </script>
</head>
<body class="container py-4">
    <header class="mb-4 text-center position-relative">
        <h1>Điện Lạnh Anh Trần Đà Nẵng</h1>
        <div class="hamburger-menu" onclick="toggleMenu()">
            &#9776;
        </div>
        <nav class="nav nav-links justify-content-center mb-3">
            <a class="nav-link" href="index.php">Trang chủ</a>
            <a class="nav-link" href="blog.php">Bài viết</a>
            <a class="nav-link" href="services.php">Dịch vụ</a>
        </nav>
    </header>

    <main>
        <section class="services-list">
            <h2 class="text-center mb-4">Dịch Vụ Của Chúng Tôi</h2>
            <div class="row justify-content-center">
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="col-md-4 col-sm-6 mb-4">
                            <div class="card h-100 shadow-sm">
                                <img src="<?php echo htmlspecialchars($row['image'], ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top mx-auto d-block" alt="<?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                <h5 class="card-title">
                                    <a href="service_detail.php?slug=<?php echo $row['service_slug']; ?>#additional_content">
                                        <?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                </h5>
                                <div class="card-body">
                                    <p class="card-text">
                                        <?php 
                                            $description = $row['description'];
                                            if (!empty($description)) {
                                                echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8');
                                            } else {
                                                echo "Mô tả không có sẵn.";
                                            }
                                        ?>
                                    </p>
                                    <?php if (!empty($row['issues'])): ?>
                                        <ul class="service-issues">
                                            <?php 
                                                $issues = explode(';', $row['issues']);
                                                foreach ($issues as $issue) {
                                                    echo '<li>' . htmlspecialchars($issue, ENT_QUOTES, 'UTF-8') . '</li>';
                                                }
                                            ?>
                                        </ul>
                                    <?php endif; ?>
                                    <a href="service_detail.php?slug=<?php echo $row['service_slug']; ?>#additional_content" class="btn btn-primary mt-3">Chi Tiết</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>Chưa có dịch vụ nào.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="articles-list mt-5">
            <h2 class="text-center mb-4">Bài Viết Mới Nhất</h2>
            <div class="row">
                <?php if ($result_articles->num_rows > 0): ?>
                    <?php while ($article = $result_articles->fetch_assoc()): ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card h-100 shadow-sm">
                                <img src="<?php echo htmlspecialchars($article['image'], ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($article['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="article_detail.php?id=<?php echo $article['id']; ?>">
                                            <?php echo htmlspecialchars($article['title'], ENT_QUOTES, 'UTF-8'); ?>
                                        </a>
                                    </h5>
                                    <p class="card-text">
                                        <?php 
                                            $content = $article['content'];
                                            echo htmlspecialchars(substr($content, 0, 100), ENT_QUOTES, 'UTF-8');
                                            if (strlen($content) > 100) {
                                                echo '...';
                                            }
                                        ?>
                                    </p>
                                    <a href="article_detail.php?id=<?php echo $article['id']; ?>" class="btn btn-primary">Xem Thêm</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>Chưa có bài viết nào.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <footer class="text-center mt-4">
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>
</body>
</html>

