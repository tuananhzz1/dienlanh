<?php
include 'config.php';

// Đặt charset cho kết nối để hỗ trợ tiếng Việt
$conn->set_charset("utf8mb4");

// Kiểm tra kết nối cơ sở dữ liệu
if ($conn->connect_error) {
    die("Kết nối cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

// Xử lý khi form được gửi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $service_slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower(trim(remove_accents($title))));
    $service_slug = preg_replace('/-+/', '-', $service_slug); // Loại bỏ các dấu gạch ngang liên tiếp
    $service_slug = trim($service_slug, '-'); // Xóa dấu gạch ngang ở đầu và cuối
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $additional_content = isset($_POST['additional_content']) ? $_POST['additional_content'] : '';
    $seo_title = isset($_POST['seo_title']) ? $_POST['seo_title'] : '';
    $seo_keywords = isset($_POST['seo_keywords']) ? $_POST['seo_keywords'] : '';
    $seo_description = isset($_POST['seo_description']) ? $_POST['seo_description'] : '';
    $issues = isset($_POST['issues']) ? $_POST['issues'] : '';
    
    // Kiểm tra nếu có tải lên file ảnh
    if (isset($_FILES['image_upload']) && $_FILES['image_upload']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image_upload"]["name"]);
        if (move_uploaded_file($_FILES["image_upload"]["tmp_name"], $target_file)) {
            $image = $target_file;
        } else {
            echo "<p>Lỗi khi tải lên file ảnh.</p>";
            $image = "";
        }
    } else {
        $image = "";
    }

    // Chuẩn bị truy vấn SQL để thêm dịch vụ mới
    $stmt = $conn->prepare("INSERT INTO services (title, service_slug, description, additional_content, image, seo_title, seo_keywords, seo_description, issues) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("sssssssss", $title, $service_slug, $description, $additional_content, $image, $seo_title, $seo_keywords, $seo_description, $issues);

        if ($stmt->execute()) {
            echo "<p>Dịch vụ đã được thêm thành công!</p>";
        } else {
            echo "<p>Lỗi khi thêm dịch vụ: " . $stmt->error . "</p>";
        }
    } else {
        echo "<p>Lỗi khi chuẩn bị truy vấn: " . $conn->error . "</p>";
    }
}

function remove_accents($str) {
    $accents = array(
        'a' => '/[\x{00E0}-\x{00E5}\x{0101}\x{01CE}\x{0201}\x{0203}\x{1EA0}-\x{1EB7}\x{1EAF}\x{1EBD}\x{1EB9}\x{1EA1}\x{1E01}]/u',
        'e' => '/[\x{00E8}-\x{00EB}\x{0113}\x{0117}\x{0205}\x{0207}\x{1EB8}-\x{1EBF}\x{1EC3}\x{1EC1}\x{1E19}\x{1E1B}]/u',
        'i' => '/[\x{00EC}-\x{00EF}\x{012B}\x{0209}\x{020B}\x{1EC8}-\x{1ECB}\x{1E2D}]/u',
        'o' => '/[\x{00F2}-\x{00F6}\x{014D}\x{01D2}\x{020D}\x{020F}\x{1ECC}-\x{1EDF}\x{1EED}\x{1ECD}\x{1E55}]/u',
        'u' => '/[\x{00F9}-\x{00FC}\x{016B}\x{01D4}\x{0215}\x{0217}\x{1EE4}-\x{1EEB}\x{1EF0}\x{1EE6}]/u',
        'y' => '/[\x{00FD}-\x{00FF}\x{1EF3}\x{1E8F}\x{1EF1}\x{1EFF}]/u'
    );

    foreach ($accents as $letter => $pattern) {
        $str = preg_replace($pattern, $letter, $str);
    }
    return $str;
}
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Dịch Vụ Mới - Điện Lạnh Anh Trần Đà Nẵng</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <script src="https://cdn.ckeditor.com/4.18.0/standard/ckeditor.js"></script>
</head>
<body class="container py-4">
    <header class="mb-4">
        <h1 class="text-center">Điện Lạnh Anh Trần Đà Nẵng</h1>
        <nav class="nav justify-content-center mb-3">
            <a class="nav-link" href="index.php">Trang chủ</a>
            <a class="nav-link" href="blog.php">Bài viết</a>
            <a class="nav-link" href="services.php">Dịch vụ</a>
        </nav>
    </header>
    <main>
        <div class="card mb-4">
            <div class="card-body">
                <h2 class="card-title text-center">Thêm Dịch Vụ Mới</h2>
                <form action="add_service.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="title" class="form-label">Tiêu đề</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Mô tả</label>
                        <textarea class="form-control" id="description" name="description" rows="5" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="additional_content" class="form-label">Nội dung khác</label>
                        <textarea class="form-control" id="additional_content" name="additional_content" rows="5"></textarea>
                        <script>
                            CKEDITOR.replace('additional_content');
                        </script>
                    </div>
                    <div class="mb-3">
                        <label for="issues" class="form-label">Các vấn đề liên quan (Mỗi vấn đề cách nhau bởi dấu chấm phẩy ";")</label>
                        <textarea class="form-control" id="issues" name="issues" rows="3" placeholder="Ví dụ: Máy chảy nước; Yếu lạnh; Đóng tuyết; Bị bụi bẩn; Có mùi hôi"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="seo_title" class="form-label">SEO Title</label>
                        <input type="text" class="form-control" id="seo_title" name="seo_title">
                    </div>
                    <div class="mb-3">
                        <label for="seo_keywords" class="form-label">SEO Keywords</label>
                        <input type="text" class="form-control" id="seo_keywords" name="seo_keywords">
                    </div>
                    <div class="mb-3">
                        <label for="seo_description" class="form-label">SEO Description</label>
                        <textarea class="form-control" id="seo_description" name="seo_description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="image_upload" class="form-label">Tải lên Ảnh</label>
                        <input type="file" class="form-control" id="image_upload" name="image_upload">
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm Dịch Vụ</button>
                </form>
            </div>
        </div>
    </main>
    <footer class="text-center mt-4">
        <p>&copy; 2024 Điện Lạnh Anh Trần Đà Nẵng. Mọi quyền được bảo lưu.</p>
    </footer>
</body>
</html>
