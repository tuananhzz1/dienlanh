
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liên Hệ - Dịch Vụ Điện Lạnh</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Liên Hệ Với Chúng Tôi</h1>
        <a href="index.php">Quay lại Trang chủ</a>
    </header>
    <main>
        <form action="contact_submit.php" method="post">
            <input type="text" name="name" placeholder="Tên của bạn" required>
            <input type="email" name="email" placeholder="Email của bạn" required>
            <textarea name="message" placeholder="Yêu cầu của bạn" required></textarea>
            <button type="submit">Gửi Yêu Cầu</button>
        </form>
    </main>
</body>
</html>
